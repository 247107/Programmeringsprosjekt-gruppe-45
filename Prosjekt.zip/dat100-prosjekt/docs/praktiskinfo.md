### Forelesninger og programmerings-lab uke 38

Der er **ikke** ordinære forelesninger i uke 38, men der vil være programmerings-lab på de vanlig tidspunktene. Her vil lab-assistenter og undervisere være til stede for å hjelpe og svare på spørsmål relatert til programmeringsprosjektet.

I tillegg vil undervisere være tilgjengelig i de rom hvor der normalt er forelesning for å svare på spørsmål og hjelpe med ting relatert til prosjektet.

### Gruppepresentasjon ved programmerings-lab uke 39

I uke 39 er det forelesninger på de vanlige tidspunktene.

I uke 39 brukes programmeringslab'en til at hver gruppe gir en kort muntlig presentasjon av prosjektet sitt for 2-3 andre grupper. Ved presentasjon må hver gruppe gi en kort demonstrasjon av java-programmene sine og gå igjennom utvalgte deler av koden og forklare hvordan oppgavene er løst. Om det er ting som gruppen ikke fikk til å fungere, kan dette også diskuteres som en del av presentasjonen.

Det er viktig at der er en logisk flytt gjennom presentasjonen så den er enkel å følge for de andre gruppene.  Det enkleste er å vise koden ved å bruke Eclipse.

**Husk** å bruke en skriftstørrelse som kan sees av tilhørerne. Skriftstørrelsen i Eclipse kan justeres ved å bruke *Ctrl +/-*. Lab-assistenter vil være tilstede på presentasjon. 

Tidspunkter og rom for de enkelte gruppene vil komme i slutten av uke 38 basert på hva som er meldt inn via Canvas ifm. etablering av grupper.
